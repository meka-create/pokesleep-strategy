ポケスリ作戦室 — E6 v41 / 2026-11-08（Android Chrome確認専用）

これは現行プレビュー3画面のみの専用ZIPです。v40以前のHTML、昔のモックやGitHub全体のファイルは含みません。

作戦: U3_Strategy_UI_20261108_v41_E6.html
準備: U2_Prep_Local_Ingredients_20261108_v41_E6.html
ボックス: U4_Box_Preview_20261108_v41_E6.html

3画面は同じフォルダにまとめて展開してください。作戦のHTMLから開くと操作を確認できます。
実ゲームの最適化はまだF工程で未実装のため、チーム・料理は表示例です。
正式公開前のDraft PR #121、main未統合です。
