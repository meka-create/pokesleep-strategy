ポケスリ作戦室 E6 v41 / 2026-11-08 / 実機確認専用

このZIPには「E6 v41」の最新HTML 3枚だけが入っています。旧版HTMLやGitHub全体は含みません。

作戦：U3_Strategy_UI_20261108_v41_E6.html
準備：U2_Prep_Local_Ingredients_20261108_v41_E6.html
ボックス：U4_Box_Preview_20261108_v41_E6.html

3ファイルを同じフォルダに展開して、作戦のHTMLを開いてください。
Android Chrome実機確認用で、正式リリースではありません。現在のパーティ・料理は例示データで、F工程の本最適化計算は未実装です。
GitHub Draft PR #121。mainには統合されていません。
